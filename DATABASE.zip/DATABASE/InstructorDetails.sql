SELECT LastName, FirstName, HireDate, AnnualSalary
FROM Instructors
ORDER BY AnnualSalary;