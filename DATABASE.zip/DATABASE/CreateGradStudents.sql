CREATE TABLE GradStudents
(StudentID INT PRIMARY KEY,
LastName VARCHAR(25) NOT NULL,
FirstName VARCHAR(25) NOT NULL,
EnrollmentDate DATE NOT NULL,
GraduationDate Date NULL);